#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time : 2023/05/13 16:41
# @Author : Jing Chen
# step3：求出最相似的10个主题
from bertopic import BERTopic

# load the model
topic_model = BERTopic.load("H:/MODEL/updated model/2015-2016/updated/tbmodel2015-2016")

# print(topic_model.get_topic_info())/

# read data
f = open(r'H:/MODEL/updated model/2015-2016/updated/tw_2015-2016.txt', 'r', encoding='utf-8') #41个主题
listdata = []
for line in f:
    line = line.strip('\n')
    listdata.append(line)

# print(listdata)
list1 = []
list2 = []
# # 求出主题相似度
for i in listdata:
        similar_topics, similarity = topic_model.find_topics(i,top_n=197)
        list1.append(str(similar_topics))
        list2.append(str(similarity))

with open("H:/MODEL/updated model/updated calculation/Topic evolution/1516-1718/1516-1718word2.txt", 'w') as f1:
    for i in list1:
        f1.write(i + '\n')
with open("H:/MODEL/updated model/updated calculation/Topic evolution/1516-1718/1516-1718prob2.txt", 'w') as f2:
    for j in list2:
        f2.write(j + '\n')
    #     print(str(similar_topics)
        #     doc2 = open('H:/组会/approach2_sim_topic.txt', 'a', encoding='utf-8')
        # print(str(similar_topics),
        # [0,3,5](输出主题的序号)
        # print(str(similarity)
        # [0.34,0.21](从大到小排列）