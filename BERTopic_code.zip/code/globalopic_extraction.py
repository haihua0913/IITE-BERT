import gensim.corpora as corpora
import pandas as pd
from bertopic import preprocess_text, BERTopic
from gensim.models.coherencemodel import CoherenceModel
from hdbscan import HDBSCAN
from keybert import KeyBERT
from sentence_transformers import SentenceTransformer
from sklearn.feature_extraction.text import CountVectorizer
from umap import UMAP
# from bertopic.vectorizers import ClassTfidfTransformer
# # load data
# from bertopic.transformers import TFIDFTransformer
from sklearn.metrics import silhouette_score

f = pd.read_excel("H:/data/Total_57994.xlsx")

listdata = []
for line in f['Abstract']:
    line = line.strip('\n')
    listdata.append(line)
# print(listdata[0:5])

#data preprocessing
preprocess_text=preprocess_text(listdata)
d = pd.DataFrame(preprocess_text)
d.to_csv('H:/MODEL/230428/preprocess_text.csv',index=False,mode='a',header=None) # mode表示追加 在追加时会将列名也作为一行进行追加，故header隐藏表头（列名）

# print(type(preprocess_text)) #<class 'list'>
# print(len(preprocess_text)) #57994

# Create an instance of the vectorizer
# vectorizer = ClassTfidfVectorizer()
# # Fit the vectorizer to your corpus
# vectorizer.fit(listdata)
#
# # Transform your corpus into a TF-IDF matrix
# tfidf_matrix = vectorizer.transform(preprocess_text)

#BERTopic 建模
# Step 1 - Extract embeddings
embedding_model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')

# # Step 2 - Reduce dimensionality
umap_model = UMAP(n_neighbors=15, n_components=5, min_dist=0.0, metric='cosine')

# # Step 3 - Cluster reduced embeddings
hdbscan_model = HDBSCAN(min_cluster_size=50, metric='euclidean', cluster_selection_method='eom', prediction_data=True)

# # Step 4 - Tokenize topics
# kw_model = KeyBERT(model='paraphrase-MiniLM-L6-v2')
# keywords = kw_model.extract_keywords(preprocess_text, keyphrase_ngram_range=(1, 3), top_n=10) #设置keyphrase_length来设置生成的keyphrase的长度
# flat_keywords = [k[0] for keyword in keywords for k in keyword]
# flat_keywords = list(set(flat_keywords))
# Pass to BERTopic
vectorizer_model = CountVectorizer(ngram_range=(2, 3),stop_words="english")


# Step 5 - Create topic representation

# ctfidf_model = TfidfTransformer()

# topic_model = BERTopic(
#     embedding_model=embedding_model,    # Step 1 - Extract embeddings
#     umap_model=umap_model,              # Step 2 - Reduce dimensionality
#     hdbscan_model=hdbscan_model,        # Step 3 - Cluster reduced embeddings
#     vectorizer_model=vectorizer_model,  # Step 4 - Tokenize topics
#     ctfidf_model=tfidf_matrix,          # Step 5 - Extract topic words
#     # diversity=0.5,                      # Step 6 - Diversify topic words
#     nr_topics="auto"
# )

## download bertopic
topic_model = BERTopic(embedding_model=embedding_model,  #1.Extract embeddings
                       umap_model=umap_model,     # Step 2 - Reduce dimensionality
                       hdbscan_model=hdbscan_model, #3.Cluster reduced embeddings
                       vectorizer_model=vectorizer_model, #4.Tokenizer topics
                       language="english",
                       nr_topics="auto",
                       n_gram_range=(2, 3),
                       calculate_probabilities=True,
                       diversity=0.5, #Diversify topic words
                       min_topic_size=50,
                       verbose=True)

# export topics and probs

topics, probs = topic_model.fit_transform(preprocess_text)
# print(len(topics))
#save topic model
topic_model.save("H:/MODEL/230428/theory_model_LIS2005-2022")
# print(topic_model.get_topic_info())

#topics
import pandas as pd
name=['topic']
test=pd.DataFrame(columns=name,data=topics)
print(test)
test.to_csv('H:/MODEL/230428/topics2005-2022.csv',encoding='gbk')


#topics and probs
df=topic_model.get_topic_info()
outputpath='H:/MODEL/230428/zhuti2005-2022.csv'
df.to_csv(outputpath,sep=',',index=False,header=False)

#total
import csv
my_Dict=topic_model.get_topics()
fileName="H:/MODEL/230428/filenamev2.csv"

with open('H:/MODEL/230428/my_file2005-2022.csv', 'w') as f:
    [f.write('{0},{1}\n'.format(key, value)) for key, value in my_Dict.items()]

#topic0
# print(topic_model.get_topic(0)) #访问单个主题


documents = pd.DataFrame({"Document": preprocess_text,
                          "ID": range(len(preprocess_text)),
                          "Topic": topics})
# print(documents.head())
