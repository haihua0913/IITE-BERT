from bertopic import BERTopic
import csv


# Load the BERTopic model
topic_model = BERTopic.load('H:/MODEL/230428/tbmodel')


visualize_topics = topic_model.visualize_topics()
visualize_topics.write_html('H:/Result/230428/visualize_topics.html')

bar_topics = topic_model.visualize_barchart(topics=[0,1,2,3,4,5])
bar_topics.write_html('H:/Result/230428/bar_topics.html')

# Get labels for each topic in a user-defined format
topic_labels = topic_model.generate_topic_labels(nr_words=1)
print(topic_labels)

import pandas as pd
name=['topic']
test=pd.DataFrame(columns=name,data=topic_labels)
# print(test)
test.to_csv('H:/MODEL/230428/topic_labels2005-2022.csv',encoding='gbk')
